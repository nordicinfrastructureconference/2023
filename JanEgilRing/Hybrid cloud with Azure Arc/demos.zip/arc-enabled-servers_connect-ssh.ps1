az login

az extension add --name ssh

$RGname = "arcbox-full-nic-2023-rg"

#region SSH against Linux

    $serverName = "Arcbox-Ubuntu-01"

<#
    Ubuntu virtual machine credentials:

    Username: arcdemo
    Password: ArcDemo123!!
#>

    # Local user
    az ssh arc --resource-group $RGname --name $serverName --local-user arcdemo

    # Entra AD - SSO (if prompted for password, make sure the AADSSHLoginForLinux extension is installed on the Azure Arc machine)
    az ssh arc --resource-group $RGname --name $serverName

#endregion

#region RDP against Windows

<#
    Windows virtual machine credentials:

    Username: Administrator
    Password: ArcDemo123!!
#>

    $serverName = "ArcBox-Win2K22"

    az ssh arc --resource-group $RGname --name $serverName --local-user administrator -rdp

#endregion

#region SSH mot Windows

    # Requires OpenSSH Server to be installed, optional feature in Windows Server 2019 and 2022
    Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
    Start-Service sshd
    Set-Service -Name sshd -StartupType 'Automatic'
    New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22

    az ssh arc --resource-group $RGname --name $serverName --local-user administrator

#endregion

#region Create an SSH config for resources (Azure VMs, Arc Servers, etc) which can then be used by clients that support OpenSSH configs and certificates.

    az ssh config --resource-group $RGname --name $serverName --file ./sshconfig
    cat ./sshconfig
    ssh -F ./sshconfig arcbox-demo-rg-Arcbox-Ubuntu-01

#endregion

#region Portal - Connect-blade from Arc-enabled server view

    Start-Process "https://portal.azure.com/#blade/HubsExtension/BrowseResource/resourceType/Microsoft.HybridCompute%2Fmachines"

#endregion