az login

az extension add --name connectedk8s

#region Service Token

$CLUSTER_NAME = "hcibox-aks-cmkhp"
$RESOURCE_GROUP = "arc-jumpstart-hcibox-01-rg"

$ServiceToken = "eyJhbGc..."

az connectedk8s proxy -n $CLUSTER_NAME -g $RESOURCE_GROUP --token $ServiceToken

#endregion